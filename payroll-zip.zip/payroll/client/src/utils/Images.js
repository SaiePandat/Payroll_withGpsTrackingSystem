import cube from "../assets/cube.png";
import profile from "../assets/profile.jpg";
import category from "../assets/category.png";
import attendence from "../assets/attendence.png";
import team from "../assets/team.png";
import motorbike from "../assets/motorbike.png";

export { cube, profile, category, attendence, team, motorbike };
