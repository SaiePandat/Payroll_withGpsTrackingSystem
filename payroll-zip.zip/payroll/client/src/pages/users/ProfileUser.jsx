import React, { useEffect, useState } from "react";
import {
  DashboardCard,
  DashboardBg,
  DashboardMain,
} from "../../utils/Styles.js";
import {
  ProfileMain,
  DashboardTabs,
  ProfileCard,
} from "../../utils/DashboardStyles.js";
import { user } from "../../utils/Icons.js";
import Sidebar from "../../components/Sidebar.js";
import Header from "../../components/Header.js";
import { Link } from "react-router-dom";
import { toast } from "alert";
import axios from "axios";

const ProfileUser = () => {
  const [tab, setTab] = useState(1);
  const toggleTab = (tab) => {
    setTab(tab);
  };

  const [userData, setUserData] = useState([]);
  const [userName, setUserName] = useState([]);
  const [loading, setLoading] = useState(false);
  const [recAddress, setRecAddress] = useState();

  const submitHandler = async () => {
    try {
      setLoading(true);
      const { data } = await axios.post(
        "http://localhost:8080/api/v1/recipient/add-recipient",
        {
          userId: userName,
          recipient_address: recAddress,
        }
      );
      setLoading(false);
      console.log(data);
      toast.success("Recipient Address is required");
      setRecAddress("");
    } catch (error) {
      setLoading(false);
      toast.error(error);
    }
  };

  useEffect(() => {
    const userData = JSON.parse(localStorage.getItem("user"));
    const username = JSON.parse(localStorage.getItem("user"));
    if (username) {
      setUserName(username);
    }
    if (userData) {
      setUserData(userData);
    }
  }, []);
  return (
    <DashboardBg>
      <DashboardMain>
        <Sidebar />
        <div>
          <Header />
        </div>
        <DashboardCard>
          <ProfileMain>
            <img src={user} alt="" />
            <div className="data">
              <h3>{userData.name}</h3>
              <p>{userData.email}</p>
            </div>
          </ProfileMain>
          <DashboardTabs>
            <li onClick={() => toggleTab(1)}>
              <Link to="#" className={tab === 1 ? "active" : ""}>
                Profile
              </Link>
              <div className={tab === 1 ? "border" : ""}></div>
            </li>
            <li onClick={() => toggleTab(3)}>
              <Link to="#" className={tab === 3 ? "active" : ""}>
                Payment Info
              </Link>
              <div className={tab === 3 ? "border" : ""}></div>
            </li>
          </DashboardTabs>
          {tab === 1 ? (
            <ProfileCard>
              <h3>Base</h3>
              <div className="grid">
                <div className="title">Name</div>
                <div className="data">{userData.name}</div>
              </div>
              <div className="grid">
                <div className="title">Email Id</div>
                <div className="data">{userData.email}</div>
              </div>
              <div className="grid">
                <div className="title">Role</div>
                <div className="data">{userData.role}</div>
              </div>
            </ProfileCard>
          ) : null}
          {tab === 3 ? (
            <ProfileCard>
              <h3>Payment Information</h3>
              <div className="input-container">
                <label>Recipient Address (required)</label>
                <input
                  type="text"
                  value={recAddress}
                  onChange={(e) => setRecAddress(e.target.value)}
                  placeholder="Add recipient aqddress of your wallet"
                />
              </div>
              <button onClick={submitHandler}>SAVE CHANGES</button>
            </ProfileCard>
          ) : null}
        </DashboardCard>
      </DashboardMain>
    </DashboardBg>
  );
};

export default ProfileUser;
