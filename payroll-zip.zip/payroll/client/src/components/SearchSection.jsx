import React from "react";
import { FaCircleDot, SiSquare } from "../utils/Icons";
import { Link } from "react-router-dom";

const SearchSection = () => {
  return (
    <></>
  );
};

export default SearchSection;
